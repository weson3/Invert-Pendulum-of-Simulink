clc;
clear;

%%cart-pole properties
global M m l g 
M = 0.5;
m = 0.5;
l = 0.3;
g = 9.81;

Joint_Damping = 1e-5;
Wheel_Damping = 1e-5;

%% car-pole initial condition 
x_0 = 0;
y_0 = 0.12;
q_0 = 180;
dq_0 = 0;

%%Controlers
LQR = 1;
if  LQR
    

    K_LQR = CarPoleLQR_GetK;
end




