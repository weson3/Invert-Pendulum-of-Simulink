clc;
clear;

%%cart-pole properties
global M m l g 
M = 0.3;
m = 0.2355;
l = 0.3;
g = 9.81;
I = 7.2e-4;

c = 7.8e-5;    %%Joint_Damping
b = 7.8e-5;
a = 0.63;   %%Wheel_Damping


%% car-pole initial condition 
x_0 = 0;
y_0 = 0.125;
p_0 = 0;
dp_0 = 0;
q_0 = 10;
dq_0 = 0;

%%Controlers






