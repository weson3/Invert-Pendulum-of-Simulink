function K_LQR = CarPoleLQR_GetK_D2(states)


%%state space matrices:
M = 0.3;
m = 0.2355;
l = 0.3;
g = 9.81;
I = 7.2e-4;

c = 7.8e-5;    %%Joint_Damping
b = 7.8e-5;
a = 0.63;   %%Wheel_Damping
%%  p→0时，sin(p)→p,cos(p) → 1
%%   S = 2*I*(m+M)+2*l^2*m*M
%% ddx = (2*g*l^2*m^2*p+2*(I+l^2*m)* F-2*(I+l^2*m)*c*dx-2*b*l*m*dp)/S
%% ddp = (2*g*l*m*(m+M)p+2*m*l*F-2*l*m*c*dx-2*b*(m+M)dp)/S
S1 = (8*(l^4*m^2*M+I^2*(2*m +M)+2*I*l^2*m*(m+3*M)));
S2 = (2*l^4*m^2*M+2*I^2*(2*m +M)+4*I*l^2*m*(m+ 3*M));
dX_p = (-2*l*m*(3*I+l^2*m)*(-l*(g*m*6))+2*(-I+l^2*m)*(-2*g*l^2*m^2))/S1;
dX_q = (-2*l*m*(3*I+l^2*m)*(-l*(g*m*(-2)))+2*(-I+l^2*m)*(-2*g*l^2*m^2))/S1;
dX_dx =(-2*l*m*(3*I+l^2*m)*(-l*(8*c*l))+2*(-I+l^2*m)*(4*c*(I+l^2*m)))/S1;
dX_dp =(-2*l*m*(3*I+l^2*m)*(-l*(4*b)))/S1;
dX_dq = (2*(-I+l^2*m)*(4*a*l*m))/S1;
dp_p = (g*l*m*(4*I*(2*m +M)+l^2*m*(3*m + 2*M)))/S2;
dp_q = (g*l*m*(2*I*m +I*M-l^2*m*M))/S2;
dp_dx = (-6*c*I*l*m-2*c*(l^3)*(m^2))/S2;
dp_dp = (-4*b*I*m-3*b*l^2*m^2-2*b*I*M-2*b*l^2*m*M+b*l^2*m^2)/S2;
dp_dq = (2*a*l^2*m*(m + 2*M))/S2;
dq_p = (g*(l^2)*(m^2)*(13*I + 3*l^2*m))/S2;
dq_q = (4*g*I*l^2*m^2)/S2;
dq_dx = (-2*c*(I^2 + 6*I*l^2*m +l^4*m^2))/S2;
dq_dp = (-2*l*m*(b*(3*I + l^2*m)))/S2;
dq_dq = (-2*l*m*(b*(a*(I-l^2*m))))/S2;
F_dx = (-2*l*m*(3*I+l^2*m)*(-l*(8)))/S1;
F_dp = (2*l*m*(3*I + l^2*m))/S2;
F_dq = (2*(I^2 + 6*I*l^2*m + l^4*m^2))/S2;

A = [0 0 0 1 0 0;
     0 0 0 0 1 0;
     0 0 0 0 0 1;
     0 dX_p dX_q dX_dx dX_dp  dX_dq;
     0 dp_p dp_q dp_dx dp_dp dp_dq;
     0 dq_p dq_q dq_dx dq_dp dq_dq];
B = [0;0;0;F_dx;F_dp;F_dq]; %% 完善状态方程  Fx 影响 ddx ddq
C = eye(6);  %%输入关系矩阵  当输入不考虑x位移时 可以将对应关系矩阵变为0
D = 0;  %%  前馈矩阵 通过输入矩阵对 %输出% 进行调节

%% build ss system:
sys = ss (A,B,C,D);

%% LQR
Q = diag([500 2000 1000 5000 40 40]);%%   x p q dx dp dq 权重 (理想状态)
R = 1;%%    （控制变量最小化限制）
sys_d = c2d(sys,0.001);%%  连续函数离散化处理
K_LQR = lqr(sys_d,Q,R);


end